# Sample Laravel-like Project
Minimal structure.