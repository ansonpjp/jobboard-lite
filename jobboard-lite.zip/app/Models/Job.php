<?php
namespace App\Models;
class Job {
    public $title; public $description; public $company; public $location; public $salary;
}